apt update -y
apt install apache2 -y
