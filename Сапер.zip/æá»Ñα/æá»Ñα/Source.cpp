﻿#include<iostream>
#include<fstream>
using namespace std;
int score = 0;
string nickname;
bool startt = true;
struct arr
{
	char fiel = ' ';
	bool bomb = false;
	int num = 0;
};
void printarr(arr field[])
{
	cout << "  1 2 3 4 5 6 7 8 9 10" << endl;
	for (size_t i = 0; i < 10; i++)
	{	
		cout << i;
		for (size_t j = 0; j < 10; j++)
		{
			cout << "|" << field[(i * 10) + j].fiel;
		}
		cout << "|" << endl;
		cout << "----------------------" << endl;
	}
}
void randbomb(arr field[])
{
	srand(time(0));
	for (size_t i = 0; i < 10; i++)
	{
		int num = rand() % 100;
		field[num].bomb = true;
	}
}
void checknum(arr field[], int num)
{
	if (num > 11 && num % 10 != 1)
	{
		if (field[num - 11].bomb)
		{
			field[num].num++;
		}
	}
	if (num > 10)
	{
		if (field[num - 10].bomb)
		{
			field[num].num++;
		}
	}
	if (num > 10 && num % 10 != 0)
	{
		if (field[num - 9].bomb == true)
		{
			field[num].num++;
		}
	}
	if (num % 10 != 1)
	{
		if (field[num - 1].bomb == true)
		{
			field[num].num++;
		}
	}
	if (num < 90 && num % 10 != 0)
	{
		if (field[num + 11].bomb == true)
		{
			field[num].num++;
		}
	}
	if (num < 91)
	{
		if (field[num + 10].bomb == true)
		{
			field[num].num++;
		}
	}
	if (num < 91 && num % 10 != 1)
	{
		if (field[num + 9].bomb == true)
		{
			field[num].num++;
		}
	}
	if (num % 10 != 0)
	{
		if (field[num + 1].bomb == true)
		{
			field[num].num++;
		}
	}
}
int checkwin(arr field[])
{
	int arr[10];
	int j = 0;
	for (size_t i = 0; i < 100; i++)
	{
		if (field[i].bomb)
		{
			arr[j] = i;
			j++;
		}
		
	}
	for (size_t i = 0; i < j; i++)
	{
		if (field[arr[i]].bomb == true && field[arr[i]].fiel == 'P')
		{

		}
		else
		{
			return 0;
		}
	}
	cout << "==================" << endl;
	cout << "YOU WIN!" << endl;
	cout << "==================" << endl;
	ofstream fout;
	score++;
	fout.open("file.txt");
	fout << nickname << ": " << score;
	fout.close();
	score++;
	while (true)
	{

	}
}

void case1(arr field[], int num)
{
	checknum(field, num);
	if (field[num].bomb)
	{
		if (startt)
		{
			field[num].fiel = ' ';
		}
		else
		{
			cout << "YOu lose";
			while (true)
			{

			}
		}
		
	}
	else
	{
		field[num].fiel = (field[num].num + 48);
	}
}
void start(arr field[], int num)
{
	for (size_t i = 32; i < 38; i++)
	{
		case1(field, i);
	}
	for (size_t i = 41; i < 49; i++)
	{
		case1(field, i);
	}
	for (size_t i = 52; i < 58; i++)
	{
		case1(field, i);
	}
	startt = false;
}
int game(arr field[])
{
	
	int choos;
	int num;
	cout << "Choose number to start 1-100 to dig: ";
	cin >> num;
	if (num < 1 || num > 100)
	{
		cout << "Wrong number!" << endl;
		game(field);
		return 0;
	}
	cout << "1.to dig: \n2.to flag: ";
	cin >> choos;
	num--;
	if (startt)
	{
		start(field, num);
	}
	
	switch (choos)
	{
	case 1:
		case1(field, num);
		
		break;
	case 2:
		field[num].fiel = 'P';
		break;
	default:
		cout << "Wrong choose" << endl;
		game(field);
		break;
	}
	
	printarr(field);
	checkwin(field);
	game(field);
	return 0;
}
void code()
{
	ifstream fin;
	fin.open("file.txt");
	fin >> nickname;
	fin >> score;
	cout << nickname << ": " << score << endl;
	cout << "Enter nickname: ";
	cin >> nickname;
	fin.close();
	ofstream fout;
	fout.open("file.txt");
	fout << nickname;
	fout.close();
}
int main()
{
	code();
	arr field[100];
	randbomb(field);
	for (size_t i = 0; i < 100; i++)
	{
		if (field[i].bomb)
		{
			field[i].fiel = 'B';
		}
	}
	printarr(field);
	game(field);
}